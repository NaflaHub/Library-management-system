/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author moham
 */
public class Member {
    
    private String memberID;
    private String name;
    private String contactInfo;
    private MembershipCard membershipCard;

    // Constructor
    public Member(String memberID, String name, String contactInfo, MembershipCard membershipCard) {
        this.memberID = memberID;
        this.name = name;
        this.contactInfo = contactInfo;
        this.membershipCard = membershipCard;
    }

    public Member(String id, String name, String contact) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    // Getters and Setters
    public String getMemberID(){
        return memberID; 
    }
    public void setMemberID(String memberID){
        this.memberID = memberID;
    }
    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name=name;
    }
    public String getContactInfo(){
        return contactInfo;
    }
    public void setContactInfo(String contactInfo){
        this.contactInfo=contactInfo;
    }
    public MembershipCard getMembershipCard() {
        return membershipCard;
    }

    public void setMembershipCard(MembershipCard membershipCard) {
        this.membershipCard = membershipCard;
    }
    // toString() method for displaying member details
        
    @Override
    public String toString() {
        return "Member ID: " + memberID + ", Name: " + name + ", Contact: " + contactInfo +
                ", Card: " + membershipCard.toString();
    }

    public Object getMemberId() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
