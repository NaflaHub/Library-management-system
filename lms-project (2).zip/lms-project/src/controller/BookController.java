/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;


import view.BookManagementView;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import view.homeView;
/**
 *
 * @author moham
 */
public class BookController {
    private final BookManagementView view;
    
    private final String DB_URL = "jdbc:mysql://localhost:3306/library";
    private final String DB_USER = "root";
    private final String DB_PASSWORD = "";
    
    public BookController(BookManagementView view) {
        this.view = view;
        
        
        view.addAddBookListener(new AddBookListener());
        view.addUpdateBookListener(new UpdateBookListener());
        view.addDeleteBookListener(new DeleteBookListener());
        view.addClearFieldsListener(new ClearFieldsListener());
        
    }
    
    class AddBookListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String id = view.getBookId();
            String title = view.getTitle();
            String author = view.getAuthor();
            String year = view.getYearPublished();
            
            if (id.isEmpty() || title.isEmpty() || author.isEmpty() || year.isEmpty()) {
                JOptionPane.showMessageDialog(view, "All fields are required.");
                return;
            }
            
           try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
                String query = "INSERT INTO bookdetails (BOOKID, TITLE, AUTHOR, YP) VALUES (?, ?, ?, ?)";
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setString(1, id);
                stmt.setString(2, title);
                stmt.setString(3, author);
                stmt.setString(4, author);
                stmt.executeUpdate();
                JOptionPane.showMessageDialog(view, "Member added successfully.");
                view.clearFields();
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(view, "Error adding member.");
            }
           
        }
    }
    
    class UpdateBookListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            
            
            String id = view.getBookId();
            String title = view.getTitle();
            String author = view.getAuthor();
            String year = view.getYearPublished();
            
            if (id.isEmpty() || title.isEmpty() || author.isEmpty() || year.isEmpty()) {
                JOptionPane.showMessageDialog(view, "All fields are required.");
                return;
            }
            
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
                String query = "UPDATE bookdetails SET TITLE = ?, AUTHOR = ?, YP =? WHERE BOOKID = ?";
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setString(1, title);
                stmt.setString(2, author);
                stmt.setString(3, year);
                stmt.setString(4, id);
                int rowsAffected = stmt.executeUpdate();
                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(view, "Member updated successfully.");
                } else {
                    JOptionPane.showMessageDialog(view, "Member ID not found.");
                }
                view.clearFields();
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(view, "Error updating member.");
            }
            
        }
    }
    
    
        
    
    class DeleteBookListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String id = view.getBookId();
            
             if (id.isEmpty()) {
                JOptionPane.showMessageDialog(view, "Book ID is required.");
                return;
            }
             
              try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
                String query = "DELETE FROM bookdetails WHERE BOOKID = ?";
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setString(1, id);
                int rowsAffected = stmt.executeUpdate();
                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(view, "BOOK deleted successfully.");
                } else {
                    JOptionPane.showMessageDialog(view, "BOOK ID not found.");
                }
                view.clearFields();
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(view, "Error deleting BOOK.");
            }
        }
        
         }
    class ClearFieldsListener implements ActionListener {
            public void actionPerformed(ActionEvent e) {
            view.clearFields();
        }
        
    }
    
   
}
