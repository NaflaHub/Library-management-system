/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;


import view.MemberManagementView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import java.sql.*;

/**
 *
 * @author moham
 */
public class MemberController {
    private final MemberManagementView view;
    
    
    private final String DB_URL = "jdbc:mysql://localhost:3308/library management";
    private final String DB_USER = "root";
    private final String DB_PASSWORD = "";
    
    
    public MemberController(MemberManagementView view) {
        this.view = view;
        

        view.addAddMemberListener(new AddMemberListener());
        view.addUpdateMemberListener(new UpdateMemberListener());
        view.addDeleteMemberListener(new DeleteMemberListener());
        view.addClearFieldsListener(new ClearFieldsListener());
    }
    
    class AddMemberListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String id = view.getMemberId();
            String name = view.getName();
            String contact = view.getContactInfo();

            if (id.isEmpty() || name.isEmpty() || contact.isEmpty()) {
                JOptionPane.showMessageDialog(view, "All fields are required.");
                return;
            }

            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
                String query = "INSERT INTO memberdetails (memberID, fullname, contactno) VALUES (?, ?, ?)";
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setString(1, id);
                stmt.setString(2, name);
                stmt.setString(3, contact);
                stmt.executeUpdate();
                JOptionPane.showMessageDialog(view, "Member added successfully.");
                view.clearFields();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(view, "Error adding member.");
            }
            
        }
    }
    class UpdateMemberListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
           

            String id = view.getMemberId();
            String name = view.getName();
            String contact = view.getContactInfo();

            if (id.isEmpty() || name.isEmpty() || contact.isEmpty()) {
                JOptionPane.showMessageDialog(view, "All fields are required.");
                return;
            }

            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
                String query = "UPDATE memberdetails SET fullname = ?, contactno = ? WHERE memberID = ?";
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setString(1, name);
                stmt.setString(2, contact);
                stmt.setString(3, id);
                int rowsAffected = stmt.executeUpdate();
                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(view, "Member updated successfully.");
                } else {
                    JOptionPane.showMessageDialog(view, "Member ID not found.");
                }
                view.clearFields();
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(view, "Error updating member.");
            }
        }
    }
    class DeleteMemberListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
           
            String id = view.getMemberId();
            
            if (id.isEmpty()) {
                JOptionPane.showMessageDialog(view, "Member ID is required.");
                return;
            }
            
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
                String query = "DELETE FROM memberdetails WHERE memberID = ?";
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setString(1, id);
                int rowsAffected = stmt.executeUpdate();
                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(view, "Member deleted successfully.");
                } else {
                    JOptionPane.showMessageDialog(view, "Member ID not found.");
                }
                view.clearFields();
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(view, "Error deleting member.");
            }

           
        }
    }
    
        class ClearFieldsListener implements ActionListener {
            public void actionPerformed(ActionEvent e) {
            view.clearFields();
            }
        }
        
   
    
}
