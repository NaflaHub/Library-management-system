/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import view.LoginView;
import javax.swing.*;
import view.homeView;


/**
 *
 * @author moham
 */
public class LoginController {
    private LoginView loginView;

    public LoginController(LoginView loginView) {
        this.loginView = loginView;

        this.loginView.getLoginButton().addActionListener(e -> authenticate());
        this.loginView.getCancelButton().addActionListener(e -> relegate());
    }
    private void relegate(){
        

        // Dispose of the loginView to close the login window
        loginView.dispose();
    }

    private void authenticate() {
        String username = loginView.getUsernameField().getText();
        String password = new String(loginView.getPasswordField().getPassword());

        if ("admin".equals(username) && "123".equals(password)) {
            
            navigateToHomePage();
            
        } else if ("member".equals(username) && "223".equals(password)){
                    navigateToHomePage();
        }else{
                JOptionPane.showMessageDialog(loginView, "Invalid credentials!");
              }
    }
    private void navigateToHomePage() {
        // Create a new HomeView instance
        homeView homeView = new homeView();
        homeView.setVisible(true);

        // Dispose of the loginView to close the login window
        loginView.dispose(); // Ensure loginView is a JFrame or its subclass
    }
}
